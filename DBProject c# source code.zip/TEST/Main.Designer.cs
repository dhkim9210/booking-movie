﻿namespace TEST
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.place_lb = new System.Windows.Forms.Label();
            this.place = new System.Windows.Forms.ComboBox();
            this.date_lb = new System.Windows.Forms.Label();
            this.reservationdate = new System.Windows.Forms.DateTimePicker();
            this.movie = new System.Windows.Forms.ComboBox();
            this.movie_lb = new System.Windows.Forms.Label();
            this.time = new System.Windows.Forms.ComboBox();
            this.Reset = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Reserve = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.seat_d10 = new System.Windows.Forms.Button();
            this.seat_d9 = new System.Windows.Forms.Button();
            this.seat_d8 = new System.Windows.Forms.Button();
            this.seat_d7 = new System.Windows.Forms.Button();
            this.seat_d6 = new System.Windows.Forms.Button();
            this.seat_d5 = new System.Windows.Forms.Button();
            this.seat_d4 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.seat_d3 = new System.Windows.Forms.Button();
            this.seat_d2 = new System.Windows.Forms.Button();
            this.seat_d1 = new System.Windows.Forms.Button();
            this.seat_c10 = new System.Windows.Forms.Button();
            this.seat_c9 = new System.Windows.Forms.Button();
            this.seat_c8 = new System.Windows.Forms.Button();
            this.seat_c7 = new System.Windows.Forms.Button();
            this.seat_c6 = new System.Windows.Forms.Button();
            this.seat_c5 = new System.Windows.Forms.Button();
            this.seat_c4 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.seat_c3 = new System.Windows.Forms.Button();
            this.seat_c2 = new System.Windows.Forms.Button();
            this.seat_c1 = new System.Windows.Forms.Button();
            this.seat_b10 = new System.Windows.Forms.Button();
            this.seat_b9 = new System.Windows.Forms.Button();
            this.seat_b8 = new System.Windows.Forms.Button();
            this.seat_b7 = new System.Windows.Forms.Button();
            this.seat_b6 = new System.Windows.Forms.Button();
            this.seat_b5 = new System.Windows.Forms.Button();
            this.seat_b4 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.seat_b3 = new System.Windows.Forms.Button();
            this.seat_b2 = new System.Windows.Forms.Button();
            this.seat_b1 = new System.Windows.Forms.Button();
            this.seat_a10 = new System.Windows.Forms.Button();
            this.seat_a9 = new System.Windows.Forms.Button();
            this.seat_a8 = new System.Windows.Forms.Button();
            this.seat_a7 = new System.Windows.Forms.Button();
            this.seat_a6 = new System.Windows.Forms.Button();
            this.seat_a5 = new System.Windows.Forms.Button();
            this.seat_a4 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.seat_a3 = new System.Windows.Forms.Button();
            this.seat_a2 = new System.Windows.Forms.Button();
            this.seat_a1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(19, 39);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(118, 21);
            this.textBox1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(143, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "님 환영합니다";
            // 
            // place_lb
            // 
            this.place_lb.AutoSize = true;
            this.place_lb.Font = new System.Drawing.Font("굴림", 10F);
            this.place_lb.Location = new System.Drawing.Point(14, 81);
            this.place_lb.Name = "place_lb";
            this.place_lb.Size = new System.Drawing.Size(35, 14);
            this.place_lb.TabIndex = 2;
            this.place_lb.Text = "장소";
            // 
            // place
            // 
            this.place.FormattingEnabled = true;
            this.place.Location = new System.Drawing.Point(56, 79);
            this.place.Name = "place";
            this.place.Size = new System.Drawing.Size(76, 20);
            this.place.TabIndex = 3;
            this.place.SelectedIndexChanged += new System.EventHandler(this.place_SelectedIndexChanged);
            // 
            // date_lb
            // 
            this.date_lb.AutoSize = true;
            this.date_lb.Font = new System.Drawing.Font("굴림", 10F);
            this.date_lb.Location = new System.Drawing.Point(15, 136);
            this.date_lb.Name = "date_lb";
            this.date_lb.Size = new System.Drawing.Size(35, 14);
            this.date_lb.TabIndex = 4;
            this.date_lb.Text = "날짜";
            // 
            // reservationdate
            // 
            this.reservationdate.Location = new System.Drawing.Point(56, 131);
            this.reservationdate.Name = "reservationdate";
            this.reservationdate.Size = new System.Drawing.Size(200, 21);
            this.reservationdate.TabIndex = 5;
            this.reservationdate.ValueChanged += new System.EventHandler(this.reservationdate_ValueChanged);
            // 
            // movie
            // 
            this.movie.FormattingEnabled = true;
            this.movie.Location = new System.Drawing.Point(56, 105);
            this.movie.Name = "movie";
            this.movie.Size = new System.Drawing.Size(200, 20);
            this.movie.TabIndex = 7;
            this.movie.SelectedIndexChanged += new System.EventHandler(this.movie_SelectedIndexChanged);
            // 
            // movie_lb
            // 
            this.movie_lb.AutoSize = true;
            this.movie_lb.Font = new System.Drawing.Font("굴림", 10F);
            this.movie_lb.Location = new System.Drawing.Point(15, 107);
            this.movie_lb.Name = "movie_lb";
            this.movie_lb.Size = new System.Drawing.Size(35, 14);
            this.movie_lb.TabIndex = 6;
            this.movie_lb.Text = "영화";
            // 
            // time
            // 
            this.time.FormattingEnabled = true;
            this.time.Location = new System.Drawing.Point(139, 158);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(118, 20);
            this.time.TabIndex = 8;
            // 
            // Reset
            // 
            this.Reset.Location = new System.Drawing.Point(21, 197);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(118, 47);
            this.Reset.TabIndex = 9;
            this.Reset.Text = "Reset";
            this.Reset.UseVisualStyleBackColor = true;
            this.Reset.Click += new System.EventHandler(this.Reset_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(145, 197);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 47);
            this.button2.TabIndex = 10;
            this.button2.Text = "Load";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 15F);
            this.label2.Location = new System.Drawing.Point(14, 277);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "List";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Location = new System.Drawing.Point(12, 304);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(436, 302);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // Reserve
            // 
            this.Reserve.Location = new System.Drawing.Point(880, 579);
            this.Reserve.Name = "Reserve";
            this.Reserve.Size = new System.Drawing.Size(112, 37);
            this.Reserve.TabIndex = 13;
            this.Reserve.Text = "Reserve";
            this.Reserve.UseVisualStyleBackColor = true;
            this.Reserve.Click += new System.EventHandler(this.Reserve_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 8F);
            this.label3.Location = new System.Drawing.Point(286, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 11);
            this.label3.TabIndex = 14;
            this.label3.Text = "잔여마일리지";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(363, 43);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(69, 21);
            this.textBox2.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 8F);
            this.label4.Location = new System.Drawing.Point(438, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 11);
            this.label4.TabIndex = 16;
            this.label4.Text = "점";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(330, 13);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(56, 23);
            this.button3.TabIndex = 17;
            this.button3.Text = "Login";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(392, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(62, 23);
            this.button4.TabIndex = 18;
            this.button4.Text = "Info";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(138, 79);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(118, 20);
            this.comboBox1.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("휴먼둥근헤드라인", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(15, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(170, 21);
            this.label5.TabIndex = 21;
            this.label5.Text = "영화예매프로그램";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Info;
            this.pictureBox1.Location = new System.Drawing.Point(288, 70);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 174);
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 11F);
            this.label6.Location = new System.Drawing.Point(316, 256);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 15);
            this.label6.TabIndex = 27;
            this.label6.Text = "제목";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 11F);
            this.label7.Location = new System.Drawing.Point(431, 283);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 15);
            this.label7.TabIndex = 26;
            this.label7.Text = "점";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("굴림", 11F);
            this.label8.Location = new System.Drawing.Point(316, 283);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 15);
            this.label8.TabIndex = 25;
            this.label8.Text = "평점";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(359, 277);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(66, 21);
            this.textBox3.TabIndex = 24;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(359, 250);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(89, 21);
            this.textBox4.TabIndex = 23;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listView1);
            this.groupBox1.Controls.Add(this.seat_d10);
            this.groupBox1.Controls.Add(this.seat_d9);
            this.groupBox1.Controls.Add(this.seat_d8);
            this.groupBox1.Controls.Add(this.seat_d7);
            this.groupBox1.Controls.Add(this.seat_d6);
            this.groupBox1.Controls.Add(this.seat_d5);
            this.groupBox1.Controls.Add(this.seat_d4);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.seat_d3);
            this.groupBox1.Controls.Add(this.seat_d2);
            this.groupBox1.Controls.Add(this.seat_d1);
            this.groupBox1.Controls.Add(this.seat_c10);
            this.groupBox1.Controls.Add(this.seat_c9);
            this.groupBox1.Controls.Add(this.seat_c8);
            this.groupBox1.Controls.Add(this.seat_c7);
            this.groupBox1.Controls.Add(this.seat_c6);
            this.groupBox1.Controls.Add(this.seat_c5);
            this.groupBox1.Controls.Add(this.seat_c4);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.seat_c3);
            this.groupBox1.Controls.Add(this.seat_c2);
            this.groupBox1.Controls.Add(this.seat_c1);
            this.groupBox1.Controls.Add(this.seat_b10);
            this.groupBox1.Controls.Add(this.seat_b9);
            this.groupBox1.Controls.Add(this.seat_b8);
            this.groupBox1.Controls.Add(this.seat_b7);
            this.groupBox1.Controls.Add(this.seat_b6);
            this.groupBox1.Controls.Add(this.seat_b5);
            this.groupBox1.Controls.Add(this.seat_b4);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.seat_b3);
            this.groupBox1.Controls.Add(this.seat_b2);
            this.groupBox1.Controls.Add(this.seat_b1);
            this.groupBox1.Controls.Add(this.seat_a10);
            this.groupBox1.Controls.Add(this.seat_a9);
            this.groupBox1.Controls.Add(this.seat_a8);
            this.groupBox1.Controls.Add(this.seat_a7);
            this.groupBox1.Controls.Add(this.seat_a6);
            this.groupBox1.Controls.Add(this.seat_a5);
            this.groupBox1.Controls.Add(this.seat_a4);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.seat_a3);
            this.groupBox1.Controls.Add(this.seat_a2);
            this.groupBox1.Controls.Add(this.seat_a1);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Font = new System.Drawing.Font("굴림", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(460, 39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(532, 534);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            // 
            // listView1
            // 
            this.listView1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(19, 326);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(490, 191);
            this.listView1.TabIndex = 75;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // seat_d10
            // 
            this.seat_d10.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_d10.Location = new System.Drawing.Point(437, 282);
            this.seat_d10.Name = "seat_d10";
            this.seat_d10.Size = new System.Drawing.Size(36, 23);
            this.seat_d10.TabIndex = 74;
            this.seat_d10.Text = "10";
            this.seat_d10.UseVisualStyleBackColor = true;
            this.seat_d10.Click += new System.EventHandler(this.seat_d10_Click);
            // 
            // seat_d9
            // 
            this.seat_d9.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_d9.Location = new System.Drawing.Point(395, 282);
            this.seat_d9.Name = "seat_d9";
            this.seat_d9.Size = new System.Drawing.Size(36, 23);
            this.seat_d9.TabIndex = 73;
            this.seat_d9.Text = "9";
            this.seat_d9.UseVisualStyleBackColor = true;
            this.seat_d9.Click += new System.EventHandler(this.seat_d9_Click);
            // 
            // seat_d8
            // 
            this.seat_d8.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_d8.Location = new System.Drawing.Point(353, 282);
            this.seat_d8.Name = "seat_d8";
            this.seat_d8.Size = new System.Drawing.Size(36, 23);
            this.seat_d8.TabIndex = 72;
            this.seat_d8.Text = "8";
            this.seat_d8.UseVisualStyleBackColor = true;
            this.seat_d8.Click += new System.EventHandler(this.seat_d8_Click);
            // 
            // seat_d7
            // 
            this.seat_d7.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_d7.Location = new System.Drawing.Point(311, 282);
            this.seat_d7.Name = "seat_d7";
            this.seat_d7.Size = new System.Drawing.Size(36, 23);
            this.seat_d7.TabIndex = 71;
            this.seat_d7.Text = "7";
            this.seat_d7.UseVisualStyleBackColor = true;
            this.seat_d7.Click += new System.EventHandler(this.seat_d7_Click);
            // 
            // seat_d6
            // 
            this.seat_d6.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_d6.Location = new System.Drawing.Point(269, 282);
            this.seat_d6.Name = "seat_d6";
            this.seat_d6.Size = new System.Drawing.Size(36, 23);
            this.seat_d6.TabIndex = 70;
            this.seat_d6.Text = "6";
            this.seat_d6.UseVisualStyleBackColor = true;
            this.seat_d6.Click += new System.EventHandler(this.seat_d6_Click);
            // 
            // seat_d5
            // 
            this.seat_d5.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_d5.Location = new System.Drawing.Point(227, 282);
            this.seat_d5.Name = "seat_d5";
            this.seat_d5.Size = new System.Drawing.Size(36, 23);
            this.seat_d5.TabIndex = 69;
            this.seat_d5.Text = "5";
            this.seat_d5.UseVisualStyleBackColor = true;
            this.seat_d5.Click += new System.EventHandler(this.seat_d5_Click);
            // 
            // seat_d4
            // 
            this.seat_d4.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_d4.Location = new System.Drawing.Point(185, 282);
            this.seat_d4.Name = "seat_d4";
            this.seat_d4.Size = new System.Drawing.Size(36, 23);
            this.seat_d4.TabIndex = 68;
            this.seat_d4.Text = "4";
            this.seat_d4.UseVisualStyleBackColor = true;
            this.seat_d4.Click += new System.EventHandler(this.seat_d4_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("굴림", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.Location = new System.Drawing.Point(16, 283);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(36, 16);
            this.label14.TabIndex = 67;
            this.label14.Text = "D열";
            // 
            // seat_d3
            // 
            this.seat_d3.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_d3.Location = new System.Drawing.Point(143, 281);
            this.seat_d3.Name = "seat_d3";
            this.seat_d3.Size = new System.Drawing.Size(36, 23);
            this.seat_d3.TabIndex = 66;
            this.seat_d3.Text = "3";
            this.seat_d3.UseVisualStyleBackColor = true;
            this.seat_d3.Click += new System.EventHandler(this.seat_d3_Click);
            // 
            // seat_d2
            // 
            this.seat_d2.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_d2.Location = new System.Drawing.Point(101, 281);
            this.seat_d2.Name = "seat_d2";
            this.seat_d2.Size = new System.Drawing.Size(36, 23);
            this.seat_d2.TabIndex = 65;
            this.seat_d2.Text = "2";
            this.seat_d2.UseVisualStyleBackColor = true;
            this.seat_d2.Click += new System.EventHandler(this.seat_d2_Click);
            // 
            // seat_d1
            // 
            this.seat_d1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_d1.Location = new System.Drawing.Point(59, 281);
            this.seat_d1.Name = "seat_d1";
            this.seat_d1.Size = new System.Drawing.Size(36, 23);
            this.seat_d1.TabIndex = 64;
            this.seat_d1.Text = "1";
            this.seat_d1.UseVisualStyleBackColor = true;
            this.seat_d1.Click += new System.EventHandler(this.seat_d1_Click);
            // 
            // seat_c10
            // 
            this.seat_c10.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_c10.Location = new System.Drawing.Point(436, 232);
            this.seat_c10.Name = "seat_c10";
            this.seat_c10.Size = new System.Drawing.Size(36, 23);
            this.seat_c10.TabIndex = 63;
            this.seat_c10.Text = "10";
            this.seat_c10.UseVisualStyleBackColor = true;
            this.seat_c10.Click += new System.EventHandler(this.seat_c10_Click);
            // 
            // seat_c9
            // 
            this.seat_c9.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_c9.Location = new System.Drawing.Point(394, 232);
            this.seat_c9.Name = "seat_c9";
            this.seat_c9.Size = new System.Drawing.Size(36, 23);
            this.seat_c9.TabIndex = 62;
            this.seat_c9.Text = "9";
            this.seat_c9.UseVisualStyleBackColor = true;
            this.seat_c9.Click += new System.EventHandler(this.seat_c9_Click);
            // 
            // seat_c8
            // 
            this.seat_c8.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_c8.Location = new System.Drawing.Point(352, 232);
            this.seat_c8.Name = "seat_c8";
            this.seat_c8.Size = new System.Drawing.Size(36, 23);
            this.seat_c8.TabIndex = 61;
            this.seat_c8.Text = "8";
            this.seat_c8.UseVisualStyleBackColor = true;
            this.seat_c8.Click += new System.EventHandler(this.seat_c8_Click);
            // 
            // seat_c7
            // 
            this.seat_c7.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_c7.Location = new System.Drawing.Point(310, 232);
            this.seat_c7.Name = "seat_c7";
            this.seat_c7.Size = new System.Drawing.Size(36, 23);
            this.seat_c7.TabIndex = 60;
            this.seat_c7.Text = "7";
            this.seat_c7.UseVisualStyleBackColor = true;
            this.seat_c7.Click += new System.EventHandler(this.seat_c7_Click);
            // 
            // seat_c6
            // 
            this.seat_c6.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_c6.Location = new System.Drawing.Point(268, 232);
            this.seat_c6.Name = "seat_c6";
            this.seat_c6.Size = new System.Drawing.Size(36, 23);
            this.seat_c6.TabIndex = 59;
            this.seat_c6.Text = "6";
            this.seat_c6.UseVisualStyleBackColor = true;
            this.seat_c6.Click += new System.EventHandler(this.seat_c6_Click);
            // 
            // seat_c5
            // 
            this.seat_c5.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_c5.Location = new System.Drawing.Point(226, 232);
            this.seat_c5.Name = "seat_c5";
            this.seat_c5.Size = new System.Drawing.Size(36, 23);
            this.seat_c5.TabIndex = 58;
            this.seat_c5.Text = "5";
            this.seat_c5.UseVisualStyleBackColor = true;
            this.seat_c5.Click += new System.EventHandler(this.seat_c5_Click);
            // 
            // seat_c4
            // 
            this.seat_c4.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_c4.Location = new System.Drawing.Point(184, 232);
            this.seat_c4.Name = "seat_c4";
            this.seat_c4.Size = new System.Drawing.Size(36, 23);
            this.seat_c4.TabIndex = 57;
            this.seat_c4.Text = "4";
            this.seat_c4.UseVisualStyleBackColor = true;
            this.seat_c4.Click += new System.EventHandler(this.seat_c4_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("굴림", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.Location = new System.Drawing.Point(15, 233);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 16);
            this.label13.TabIndex = 56;
            this.label13.Text = "C열";
            // 
            // seat_c3
            // 
            this.seat_c3.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_c3.Location = new System.Drawing.Point(142, 231);
            this.seat_c3.Name = "seat_c3";
            this.seat_c3.Size = new System.Drawing.Size(36, 23);
            this.seat_c3.TabIndex = 55;
            this.seat_c3.Text = "3";
            this.seat_c3.UseVisualStyleBackColor = true;
            this.seat_c3.Click += new System.EventHandler(this.seat_c3_Click);
            // 
            // seat_c2
            // 
            this.seat_c2.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_c2.Location = new System.Drawing.Point(100, 231);
            this.seat_c2.Name = "seat_c2";
            this.seat_c2.Size = new System.Drawing.Size(36, 23);
            this.seat_c2.TabIndex = 54;
            this.seat_c2.Text = "2";
            this.seat_c2.UseVisualStyleBackColor = true;
            this.seat_c2.Click += new System.EventHandler(this.seat_c2_Click);
            // 
            // seat_c1
            // 
            this.seat_c1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_c1.Location = new System.Drawing.Point(58, 231);
            this.seat_c1.Name = "seat_c1";
            this.seat_c1.Size = new System.Drawing.Size(36, 23);
            this.seat_c1.TabIndex = 53;
            this.seat_c1.Text = "1";
            this.seat_c1.UseVisualStyleBackColor = true;
            this.seat_c1.Click += new System.EventHandler(this.seat_c1_Click);
            // 
            // seat_b10
            // 
            this.seat_b10.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_b10.Location = new System.Drawing.Point(436, 178);
            this.seat_b10.Name = "seat_b10";
            this.seat_b10.Size = new System.Drawing.Size(36, 23);
            this.seat_b10.TabIndex = 52;
            this.seat_b10.Text = "10";
            this.seat_b10.UseVisualStyleBackColor = true;
            this.seat_b10.Click += new System.EventHandler(this.seat_b10_Click);
            // 
            // seat_b9
            // 
            this.seat_b9.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_b9.Location = new System.Drawing.Point(394, 178);
            this.seat_b9.Name = "seat_b9";
            this.seat_b9.Size = new System.Drawing.Size(36, 23);
            this.seat_b9.TabIndex = 51;
            this.seat_b9.Text = "9";
            this.seat_b9.UseVisualStyleBackColor = true;
            this.seat_b9.Click += new System.EventHandler(this.seat_b9_Click);
            // 
            // seat_b8
            // 
            this.seat_b8.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_b8.Location = new System.Drawing.Point(352, 178);
            this.seat_b8.Name = "seat_b8";
            this.seat_b8.Size = new System.Drawing.Size(36, 23);
            this.seat_b8.TabIndex = 50;
            this.seat_b8.Text = "8";
            this.seat_b8.UseVisualStyleBackColor = true;
            this.seat_b8.Click += new System.EventHandler(this.seat_b8_Click);
            // 
            // seat_b7
            // 
            this.seat_b7.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_b7.Location = new System.Drawing.Point(310, 178);
            this.seat_b7.Name = "seat_b7";
            this.seat_b7.Size = new System.Drawing.Size(36, 23);
            this.seat_b7.TabIndex = 49;
            this.seat_b7.Text = "7";
            this.seat_b7.UseVisualStyleBackColor = true;
            this.seat_b7.Click += new System.EventHandler(this.seat_b7_Click);
            // 
            // seat_b6
            // 
            this.seat_b6.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_b6.Location = new System.Drawing.Point(268, 178);
            this.seat_b6.Name = "seat_b6";
            this.seat_b6.Size = new System.Drawing.Size(36, 23);
            this.seat_b6.TabIndex = 48;
            this.seat_b6.Text = "6";
            this.seat_b6.UseVisualStyleBackColor = true;
            this.seat_b6.Click += new System.EventHandler(this.seat_b6_Click);
            // 
            // seat_b5
            // 
            this.seat_b5.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_b5.Location = new System.Drawing.Point(226, 178);
            this.seat_b5.Name = "seat_b5";
            this.seat_b5.Size = new System.Drawing.Size(36, 23);
            this.seat_b5.TabIndex = 47;
            this.seat_b5.Text = "5";
            this.seat_b5.UseVisualStyleBackColor = true;
            this.seat_b5.Click += new System.EventHandler(this.seat_b5_Click);
            // 
            // seat_b4
            // 
            this.seat_b4.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_b4.Location = new System.Drawing.Point(184, 178);
            this.seat_b4.Name = "seat_b4";
            this.seat_b4.Size = new System.Drawing.Size(36, 23);
            this.seat_b4.TabIndex = 46;
            this.seat_b4.Text = "4";
            this.seat_b4.UseVisualStyleBackColor = true;
            this.seat_b4.Click += new System.EventHandler(this.seat_b4_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("굴림", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.Location = new System.Drawing.Point(15, 179);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 16);
            this.label12.TabIndex = 45;
            this.label12.Text = "B열";
            // 
            // seat_b3
            // 
            this.seat_b3.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_b3.Location = new System.Drawing.Point(142, 177);
            this.seat_b3.Name = "seat_b3";
            this.seat_b3.Size = new System.Drawing.Size(36, 23);
            this.seat_b3.TabIndex = 44;
            this.seat_b3.Text = "3";
            this.seat_b3.UseVisualStyleBackColor = true;
            this.seat_b3.Click += new System.EventHandler(this.seat_b3_Click);
            // 
            // seat_b2
            // 
            this.seat_b2.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_b2.Location = new System.Drawing.Point(100, 177);
            this.seat_b2.Name = "seat_b2";
            this.seat_b2.Size = new System.Drawing.Size(36, 23);
            this.seat_b2.TabIndex = 43;
            this.seat_b2.Text = "2";
            this.seat_b2.UseVisualStyleBackColor = true;
            this.seat_b2.Click += new System.EventHandler(this.seat_b2_Click);
            // 
            // seat_b1
            // 
            this.seat_b1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_b1.Location = new System.Drawing.Point(58, 177);
            this.seat_b1.Name = "seat_b1";
            this.seat_b1.Size = new System.Drawing.Size(36, 23);
            this.seat_b1.TabIndex = 42;
            this.seat_b1.Text = "1";
            this.seat_b1.UseVisualStyleBackColor = true;
            this.seat_b1.Click += new System.EventHandler(this.seat_b1_Click);
            // 
            // seat_a10
            // 
            this.seat_a10.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_a10.Location = new System.Drawing.Point(436, 126);
            this.seat_a10.Name = "seat_a10";
            this.seat_a10.Size = new System.Drawing.Size(36, 23);
            this.seat_a10.TabIndex = 41;
            this.seat_a10.Text = "10";
            this.seat_a10.UseVisualStyleBackColor = true;
            this.seat_a10.Click += new System.EventHandler(this.seat_a10_Click);
            // 
            // seat_a9
            // 
            this.seat_a9.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_a9.Location = new System.Drawing.Point(394, 126);
            this.seat_a9.Name = "seat_a9";
            this.seat_a9.Size = new System.Drawing.Size(36, 23);
            this.seat_a9.TabIndex = 40;
            this.seat_a9.Text = "9";
            this.seat_a9.UseVisualStyleBackColor = true;
            this.seat_a9.Click += new System.EventHandler(this.seat_a9_Click);
            // 
            // seat_a8
            // 
            this.seat_a8.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_a8.Location = new System.Drawing.Point(352, 126);
            this.seat_a8.Name = "seat_a8";
            this.seat_a8.Size = new System.Drawing.Size(36, 23);
            this.seat_a8.TabIndex = 39;
            this.seat_a8.Text = "8";
            this.seat_a8.UseVisualStyleBackColor = true;
            this.seat_a8.Click += new System.EventHandler(this.seat_a8_Click);
            // 
            // seat_a7
            // 
            this.seat_a7.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_a7.Location = new System.Drawing.Point(310, 126);
            this.seat_a7.Name = "seat_a7";
            this.seat_a7.Size = new System.Drawing.Size(36, 23);
            this.seat_a7.TabIndex = 38;
            this.seat_a7.Text = "7";
            this.seat_a7.UseVisualStyleBackColor = true;
            this.seat_a7.Click += new System.EventHandler(this.seat_a7_Click);
            // 
            // seat_a6
            // 
            this.seat_a6.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_a6.Location = new System.Drawing.Point(268, 126);
            this.seat_a6.Name = "seat_a6";
            this.seat_a6.Size = new System.Drawing.Size(36, 23);
            this.seat_a6.TabIndex = 37;
            this.seat_a6.Text = "6";
            this.seat_a6.UseVisualStyleBackColor = true;
            this.seat_a6.Click += new System.EventHandler(this.seat_a6_Click);
            // 
            // seat_a5
            // 
            this.seat_a5.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_a5.Location = new System.Drawing.Point(226, 126);
            this.seat_a5.Name = "seat_a5";
            this.seat_a5.Size = new System.Drawing.Size(36, 23);
            this.seat_a5.TabIndex = 36;
            this.seat_a5.Text = "5";
            this.seat_a5.UseVisualStyleBackColor = true;
            this.seat_a5.Click += new System.EventHandler(this.seat_a5_Click);
            // 
            // seat_a4
            // 
            this.seat_a4.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_a4.Location = new System.Drawing.Point(184, 126);
            this.seat_a4.Name = "seat_a4";
            this.seat_a4.Size = new System.Drawing.Size(36, 23);
            this.seat_a4.TabIndex = 35;
            this.seat_a4.Text = "4";
            this.seat_a4.UseVisualStyleBackColor = true;
            this.seat_a4.Click += new System.EventHandler(this.seat_a4_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("굴림", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.Location = new System.Drawing.Point(15, 127);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 16);
            this.label11.TabIndex = 34;
            this.label11.Text = "A열";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("굴림", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(204, 69);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 20);
            this.label10.TabIndex = 33;
            this.label10.Text = "Screen";
            // 
            // seat_a3
            // 
            this.seat_a3.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_a3.Location = new System.Drawing.Point(142, 125);
            this.seat_a3.Name = "seat_a3";
            this.seat_a3.Size = new System.Drawing.Size(36, 23);
            this.seat_a3.TabIndex = 32;
            this.seat_a3.Text = "3";
            this.seat_a3.UseVisualStyleBackColor = true;
            this.seat_a3.Click += new System.EventHandler(this.seat_a3_Click);
            // 
            // seat_a2
            // 
            this.seat_a2.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_a2.Location = new System.Drawing.Point(100, 125);
            this.seat_a2.Name = "seat_a2";
            this.seat_a2.Size = new System.Drawing.Size(36, 23);
            this.seat_a2.TabIndex = 31;
            this.seat_a2.Text = "2";
            this.seat_a2.UseVisualStyleBackColor = true;
            this.seat_a2.Click += new System.EventHandler(this.seat_a2_Click);
            // 
            // seat_a1
            // 
            this.seat_a1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.seat_a1.Location = new System.Drawing.Point(58, 125);
            this.seat_a1.Name = "seat_a1";
            this.seat_a1.Size = new System.Drawing.Size(36, 23);
            this.seat_a1.TabIndex = 30;
            this.seat_a1.Text = "1";
            this.seat_a1.UseVisualStyleBackColor = true;
            this.seat_a1.Click += new System.EventHandler(this.seat_a1_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(15, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 16);
            this.label9.TabIndex = 29;
            this.label9.Text = "자리예약";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(917, 12);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 29;
            this.button5.Text = "Exit";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(752, 579);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 37);
            this.button1.TabIndex = 30;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(803, 12);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(108, 23);
            this.button6.TabIndex = 31;
            this.button6.Text = "Database Reset";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 628);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Reserve);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Reset);
            this.Controls.Add(this.time);
            this.Controls.Add(this.movie);
            this.Controls.Add(this.movie_lb);
            this.Controls.Add(this.reservationdate);
            this.Controls.Add(this.date_lb);
            this.Controls.Add(this.place);
            this.Controls.Add(this.place_lb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Name = "Main";
            this.Text = "xsz";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label place_lb;
        private System.Windows.Forms.ComboBox place;
        private System.Windows.Forms.Label date_lb;
        private System.Windows.Forms.DateTimePicker reservationdate;
        private System.Windows.Forms.ComboBox movie;
        private System.Windows.Forms.Label movie_lb;
        private System.Windows.Forms.ComboBox time;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Reserve;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button seat_d10;
        private System.Windows.Forms.Button seat_d9;
        private System.Windows.Forms.Button seat_d8;
        private System.Windows.Forms.Button seat_d7;
        private System.Windows.Forms.Button seat_d6;
        private System.Windows.Forms.Button seat_d5;
        private System.Windows.Forms.Button seat_d4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button seat_d3;
        private System.Windows.Forms.Button seat_d2;
        private System.Windows.Forms.Button seat_d1;
        private System.Windows.Forms.Button seat_c10;
        private System.Windows.Forms.Button seat_c9;
        private System.Windows.Forms.Button seat_c8;
        private System.Windows.Forms.Button seat_c7;
        private System.Windows.Forms.Button seat_c6;
        private System.Windows.Forms.Button seat_c5;
        private System.Windows.Forms.Button seat_c4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button seat_c3;
        private System.Windows.Forms.Button seat_c2;
        private System.Windows.Forms.Button seat_c1;
        private System.Windows.Forms.Button seat_b10;
        private System.Windows.Forms.Button seat_b9;
        private System.Windows.Forms.Button seat_b8;
        private System.Windows.Forms.Button seat_b7;
        private System.Windows.Forms.Button seat_b6;
        private System.Windows.Forms.Button seat_b5;
        private System.Windows.Forms.Button seat_b4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button seat_b3;
        private System.Windows.Forms.Button seat_b2;
        private System.Windows.Forms.Button seat_b1;
        private System.Windows.Forms.Button seat_a10;
        private System.Windows.Forms.Button seat_a9;
        private System.Windows.Forms.Button seat_a8;
        private System.Windows.Forms.Button seat_a7;
        private System.Windows.Forms.Button seat_a6;
        private System.Windows.Forms.Button seat_a5;
        private System.Windows.Forms.Button seat_a4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button seat_a3;
        private System.Windows.Forms.Button seat_a2;
        private System.Windows.Forms.Button seat_a1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button6;
    }
}